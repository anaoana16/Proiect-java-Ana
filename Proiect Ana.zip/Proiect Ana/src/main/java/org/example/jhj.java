
import javax.swing.*;
import javax.swing.table.*;

public class jhj extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTable table;

    public jhj() {
        Object[] columnNames = {"ID", "Nume", "Prenume", "Varsta", "Student"};
        Object[][] data = {
                {"1", "Vaida", "Ana", 10, new Boolean(true)},
                {"2", "Cristea", "Oana", 47, new Boolean(false)},
                {"3", "Tripon", "Mara", 66, new Boolean(false)},
                {"4", "Opis", "Alex", 25, new Boolean(false)},
                {"5", "Ardelean", "Tania", 30, new Boolean(false)},
                {"6", "Cioban", "Sergiu", 22, new Boolean(true)},
                {"7", "Balog", "Marcel", 40, new Boolean(false)},
                {"8", "Rad", "Ioana", 45, new Boolean(false)},
                {"9", "Coste", "Adonis", 50, new Boolean(false)},
                {"10", "Cheregi", "Livia", 60, new Boolean(false)}
        };
        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        table = new JTable(model) {

            private static final long serialVersionUID = 1L;


            @Override
            public Class getColumnClass(int column) {
                switch (column) {
                    case 0:
                        return String.class;
                    case 1:
                        return String.class;
                    case 2:
                        return Integer.class;
                    case 3:
                        return Double.class;
                    default:
                        return Boolean.class;
                }
            }
        };
        table.setPreferredScrollableViewportSize(table.getPreferredSize());
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                jhj frame = new jhj();
                frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
                frame.pack();
                frame.setLocation(150, 150);
                frame.setVisible(true);
            }
        });
    }
}