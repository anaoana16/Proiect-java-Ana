

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

public class Main extends JFrame{

    Main()
    {
        JPanel panel;
        JScrollPane ScrollPane;
        JTable table;

        setTitle("JTable Header");
        setSize(500,350);

        panel = new JPanel(new BorderLayout());

        Object[][] data = {
                {1, "Vaida ","Ana",10,new Boolean(true)},
                {2, "Cristea" ,"Oana",47,new Boolean(false)},
                {3, "Tripon","Mara",66,new Boolean(false)},
                {4, "Opris","Alex",25,new Boolean(false)},
                {5, "Ardelean","Tania",30,new Boolean(false)},
                {6, "Cioban","Sergiu",22,new Boolean(true)},
                {7, "Balog","Marcel",40,new Boolean(false)},
                {8, "Rad","Ioana",45,new Boolean(false)},
                {9, "Coste","Adonis",50,new Boolean(false)},
                {10, "Cheregi","Estera",60,new Boolean(false)}
        };


        table = new JTable(data, new Object[]{"ID","Nume","Prenume","Varsta","Student"});

        ScrollPane = new JScrollPane(table);
        panel.add(ScrollPane, BorderLayout.CENTER);
        setContentPane(panel);

        JTableHeader Theader = table.getTableHeader();

        Theader.setBackground(Color.pink); // change the Background color
        Theader.setForeground(Color.yellow); // change the Foreground

        Theader.setFont(new Font("Tahome", Font.BOLD, 14)); // font name style size
        ((DefaultTableCellRenderer)Theader.getDefaultRenderer())
                .setHorizontalAlignment(JLabel.CENTER); // center header text

        table.setFont(new Font("Tahome", Font.BOLD, 14));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public static void main(String arg[]) {
        Main th  = new Main();
        th.setVisible( true );

    }

}
